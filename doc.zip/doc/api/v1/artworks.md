## POST /api/v1/artworks
ステータスコードが201であること.

### Example

#### Request
```
POST /api/v1/artworks.json HTTP/1.1
Accept: text/xml,application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5
Content-Length: 11
Content-Type: application/x-www-form-urlencoded
Host: www.example.com

title=title
```

#### Response
```
HTTP/1.1 201
Cache-Control: max-age=0, private, must-revalidate
Content-Length: 173
Content-Type: application/json; charset=utf-8
ETag: W/"883ed30864c38a08c1d749c72299e4a3"
Location: http://www.example.com/api/v1/artworks/1
X-Request-Id: fa944bc2-eee6-49e6-a0f4-bf8b8f1eda66
X-Runtime: 0.077548

{
  "id": 1,
  "user_id": null,
  "title": "title",
  "created_at": "2018-05-25T08:49:28.319Z",
  "updated_at": "2018-05-25T08:49:28.319Z",
  "url": "http://www.example.com/api/v1/artworks/1.json"
}
```
